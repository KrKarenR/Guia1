
package com.mycompany.parqueadero;

//Se importa la clase LocalDateTime para registrar la hora de entrada del vehiculo.
import java.time.LocalDateTime;
      
//Se registra la clase Vehiculo como abstracta ya que no se instancia directamente
//y nos sirve como plantilla para las clases automovil, motocicleta y camion. 
public abstract class Vehiculo {

	private String placa;
	private String marca;
	private String modelo;
	private LocalDateTime horaEntrada;
        
        //Clase de tipo constructor que asigna o inicializa el valor de recibido a
        //cada atrbuto de la clase.
        public Vehiculo(String placa, String marca, String modelo){
            this.placa = placa;
            this.marca = marca;
            this.modelo = modelo;
            this.horaEntrada = LocalDateTime.now();          
        }
        
        //Getters y Setters que permiten obtener o modificar los valores de los atributos.
	public String getPlaca() {
		return this.placa;
	}

	/**
	 * 
	 * @param placa
	 */
	public void setPlaca(String placa) {
		this.placa = placa;
	}

	public String getMarca() {
		return this.marca;
	}

	/**
	 * 
	 * @param marca
	 */
	public void setMarca(String marca) {
		this.marca = marca;
	}

	public String getModelo() {
		return this.modelo;
	}

	/**
	 * 
	 * @param modelo
	 */
	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public LocalDateTime getHoraEntrada() {
		return this.horaEntrada;
	}

	/**
	 * 
	 * @param horaEntrada
	 */
	public void setHoraEntrada(LocalDateTime horaEntrada) {
		this.horaEntrada = horaEntrada;
	}
        //Esta clase se utilizará en las clases automovil, motocilceta y camion, 
        //este es el metodo para calcular la tarifa segun el vehiculo.
        public abstract double calcularTarifa(long horas);
 
        //Este metodo permitirá realizar la consulta de los vehiculos registrados. 
        public String mostrarInformacion(){
            return "Placa: " + placa + " Marca: " + marca + " Modelo: " + modelo + " Entrada: " + horaEntrada;
        }
                
}