
package com.mycompany.parqueadero;

//Importamos las clases Duration y LocalDateTime para calcular el valor del
//parqueadero segun la hora de ingreso y la hora de salida. Usamos las clases
//ArrayList y List para guardar los vehiculos que ingresan al parqueadero.
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Parqueadero {
        
        //Aqui creamos una lista de objetos la cual contiene todos los vehiculos
        //dentro del parqueadero sin importar el tipo.
        private List<Vehiculo> vehiculos = new ArrayList<>();
        
        //Este metodo recibe un objeto vehiculo de cualquier tipo y lo agrega a
        //la lista de vehiculos del parqueadero.
	public void registrarEntrada(Vehiculo v) {
		vehiculos.add(v);
                System.out.println("¡Vehículo registrado!");
	}
        
        //En este metodo se recibe el parametro de placa, la cual es almacenada
        //en la variable declarada encontrado y busca el vehiculo con esta placa.
	public void registrarSalida(String placa) {
		Vehiculo encontrado = null;
                for (Vehiculo v : vehiculos){
                    if(v.getPlaca().equalsIgnoreCase(placa)){
                        encontrado = v;
                        break;
                    }
                }
                
                //En caso de que el vehiculo sea encontrado calcula la tarifa
                // Esto lo hace calculando la diferencia de tiempo entrea la hora de
                //entrada y la hora actual, despues lo convierte en horas y lo redondea.
                if(encontrado != null){
                    long minutos = Duration.between(encontrado.getHoraEntrada(), LocalDateTime.now()).toMinutes();
                    long horas = minutos / 60;
                    if (minutos % 60 != 0) horas++;
                    
                    //Despues de calculada la tarifa elimina el vehiculo del parqueadero
                    //e imprime el valor total a pagar
                    double tarifa = encontrado.calcularTarifa(horas);
                    vehiculos.remove(encontrado);
                    System.out.println("Salida registrada. Valor a pagar: $" + tarifa);
                }else{
                    System.out.println("¡El vehiculo ingresado no se encuenta registrado!");
                }
	}

        //Con este metodo es posible imprimir todos lo vehiculos dentro del parqueadero
        //en caso de no existir se mostrá un mensaje indicandolo.
	public void mostrarVehiculos() {
		if(vehiculos.isEmpty()){
                    System.out.println("El parqueadero no tiene vehiculos registrados");
                }else{
                    System.out.println("Vehículos presentes en parqueadero:");
                    for(Vehiculo v : vehiculos){
                        System.out.println(v.mostrarInformacion());
                    }
                }
	}

}