
package com.mycompany.parqueadero;

//Se importa la clase Scanner para leer los datos que son ingresados por consola.
import java.util.Scanner;

/**
 *
 * @author krkar
 */
public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero();
        boolean salir = false;
        
        while(!salir){
            System.out.println("MENÚ PRINCIPAL");
            System.out.println("1. Registrar nuevo vehículo");
            System.out.println("2. Registrar salida de vehiculo");
            System.out.println("3. Consultar parqueadero");
            System.out.println("4. Salir");
            System.out.println("Seleccione una opción: ");
            
            int opcion = sc.nextInt();
            sc.nextLine();
            
            switch (opcion){
                case 1:
                    System.out.println("Ingrese el tipo de vehiculo: ");
                    System.out.println("1. Automóvil\n2. Motocicleta\n3. Camión");
                    int tipo = sc.nextInt();
                    sc.nextLine();
                    
                    System.out.println("Placa: ");
                    String placa = sc.nextLine();
                    System.out.println("Marca: ");
                    String marca = sc.nextLine();
                    System.out.println("Modelo: ");
                    String modelo = sc.nextLine();
                    
                    if (tipo ==1){
                        System.out.println("Tipo de combustible: ");
                        String combustible = sc.nextLine();
                        parqueadero.registrarEntrada(new Automovil(placa, marca, modelo, combustible));
                    }else if (tipo == 2){
                        System.out.println("Cilindraje (cc): ");
                        int cilindraje = sc.nextInt();
                        sc.nextLine();
                        parqueadero.registrarEntrada(new Motocicleta(placa, marca, modelo, cilindraje));
                    }else if (tipo == 3){
                        System.out.println("Capacidad de carga (Toneladas): ");
                        double capacidad = sc.nextDouble();
                        sc.nextLine();
                        parqueadero.registrarEntrada(new Camion(placa, marca, modelo, capacidad));
                    }else{
                        System.out.println("¡Tipo ingresado no válido!");
                    }
                    break;
                    
                case 2:
                    System.out.println("Ingrese la placa: ");
                    String salida = sc.nextLine();
                    parqueadero.registrarSalida(salida);
                    break;
                    
                case 3:
                    parqueadero.mostrarVehiculos();;
                    break;
                    
                case 4:
                    salir = true;
                    System.out.println("¡Programa finalizado!");
                    break;
                    
                default:
                    System.out.println("¡La opción ingresada es inválida!");
                    
            }
        }
        sc.close();
    }
}
