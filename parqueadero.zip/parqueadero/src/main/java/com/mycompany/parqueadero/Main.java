
package com.mycompany.parqueadero;

//Se importa la clase Scanner para leer los datos que son ingresados por consola.
import java.util.Scanner;

/**
 *
 * @author krkar
 */
public class Main {

    //Se crean los objetos que permite la lectura de daots ingresados por consola,
    //objeto parqueadero para la gestion de los vehiculos y una variable booleana
    //para controlar el ciclo del menu principal
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Parqueadero parqueadero = new Parqueadero();
        boolean salir = false;
        
        //Mientras la variable salir sea falsa se seguirá mostrando el menú.
        while(!salir){
            System.out.println("MENÚ PRINCIPAL");
            System.out.println("1. Registrar nuevo vehículo");
            System.out.println("2. Registrar salida de vehiculo");
            System.out.println("3. Consultar parqueadero");
            System.out.println("4. Salir");
            System.out.println("Seleccione una opción: ");
            
            int opcion = sc.nextInt();
            sc.nextLine();
            
            //Dependiendo de la opción ingresada se mostrarán los casos
            switch (opcion){
                //Caso 1 Ingreso de un nuevo vehiculo al parqueadero.
                case 1:
                    System.out.println("Ingrese el tipo de vehiculo: ");
                    System.out.println("1. Automóvil\n2. Motocicleta\n3. Camión");
                    int tipo = sc.nextInt();
                    sc.nextLine();
                    
                    System.out.println("Placa: ");
                    String placa = sc.nextLine();
                    System.out.println("Marca: ");
                    String marca = sc.nextLine();
                    System.out.println("Modelo: ");
                    String modelo = sc.nextLine();
                    
                    //Dependiendo el tipo de vehiculo se solicitará el cilindraje,
                    //la capacidad de carga o el tipo de conbustible.
                    if (tipo ==1){
                        System.out.println("Tipo de combustible: ");
                        String combustible = sc.nextLine();
                        parqueadero.registrarEntrada(new Automovil(placa, marca, modelo, combustible));
                    }else if (tipo == 2){
                        System.out.println("Cilindraje (cc): ");
                        int cilindraje = sc.nextInt();
                        sc.nextLine();
                        parqueadero.registrarEntrada(new Motocicleta(placa, marca, modelo, cilindraje));
                    }else if (tipo == 3){
                        System.out.println("Capacidad de carga (Toneladas): ");
                        double capacidad = sc.nextDouble();
                        sc.nextLine();
                        parqueadero.registrarEntrada(new Camion(placa, marca, modelo, capacidad));
                    }else{
                        System.out.println("¡Tipo ingresado no válido!");
                    }
                    break;
                
                //Caso 2 Salida de un vehículo.
                case 2:
                    System.out.println("Ingrese la placa: ");
                    String salida = sc.nextLine();
                    parqueadero.registrarSalida(salida);
                    break;
                    
                //Caso 3 Consultar vehiculos.    
                case 3:
                    parqueadero.mostrarVehiculos();;
                    break;
                
                //Caso 4 Salir del programa.    
                case 4:
                    salir = true;
                    System.out.println("¡Programa finalizado!");
                    break;
               
                //Caso por defecto, cuando la opción ingresada es invalida.    
                default:
                    System.out.println("¡La opción ingresada es inválida!");
                    
            }
        }
        sc.close();
    }
}
