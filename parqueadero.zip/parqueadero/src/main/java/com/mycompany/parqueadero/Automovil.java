
package com.mycompany.parqueadero;

//En este caso la case automovil hereda de la clase Vehiculo
public class Automovil extends Vehiculo {
    
        //En este caso se define la constante TARIFA_HORA para que pueda ser compartida
        //con todos los objetos de automovil y como final para que no se pueda modificar
        //despues de asignarla, allí se define el valor de hora para los automoviles.
        private static final double TARIFA_HORA = 11460;
	private String tipoCombustible;

        //Clase de tipo constructor en este caso se usa super para acceeder a la
        //clase padre que en este caso es Vehiculo, ya que automovil extiende de vehiculo.
        public Automovil(String placa, String marca, String modelo, String tipoCombustible){
            super(placa, marca, modelo);
            this.tipoCombustible = tipoCombustible;
        }

        //Getter y Setter del atributo tipo de combustible
        public String getTipoCombustible() {
            return tipoCombustible;
        }

        public void setTipoCombustible(String tipoCombustible) {
            this.tipoCombustible = tipoCombustible;
        }
        
        //Este metodo ya está definido en la clase padre, en este caso lo que
        //hacemos con override es sobreescribir ya que en este caso dentro de la
        //clase automovil ya definimos la tarifa hora por lo que es necesario
        //sobreescribir el contenido de este metodo para implementarlo.
        @Override
        public double calcularTarifa(long horas){
            return horas * TARIFA_HORA;
        }
        
        //En este caso estamos usando override tambien para sobreescribir el metodo
        //de la clase vehiculo y al retornar estamos llamando a la clase padre para
        //que nos pase los datos de placa, marca, modelo, hora de entrada y lo estamos
        //concatenando con el tipo de combustible para que nos muestre toda esta información
        @Override
        public String mostrarInformacion(){
            return super.mostrarInformacion() + " Conbustible: " + tipoCombustible;
        }
}