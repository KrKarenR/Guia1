
package com.mycompany.parqueadero;

//Clase motocicleta que hereda de vehiculo
public class Camion extends Vehiculo {

        //En este caso se define la constante TARIFA_HORA para que pueda ser compartida
        //con todos los objetos de camion y como final para que no se pueda modificar
        //despues de asignarla, allí se define el valor de hora para los camiones.
        private static final double TARIFA_HORA = 12060;
	private double capacidadCarga;

        //Clase de tipo constructor en este caso se usa super para acceeder a la
        //clase padre que en este caso es Vehiculo, ya que camion extiende de vehiculo.
        public Camion(String placa, String marca, String modelo, double capacidadCarga) {
            super(placa, marca, modelo);
            this.capacidadCarga = capacidadCarga;
        }

        //Getter y Setter del atributo capacidad de carga
        public double getCapacidadCarga() {
            return capacidadCarga;
        }

        public void setCapacidadCarga(double capacidadCarga) {
            this.capacidadCarga = capacidadCarga;
        }

        //Este metodo ya está definido en la clase padre, en este caso lo que
        //hacemos con override es sobreescribir ya que en este caso dentro de la
        //clase camion ya definimos la tarifa hora por lo que es necesario
        //sobreescribir el contenido de este metodo para implementarlo.
        @Override
        public double calcularTarifa(long horas){
            return horas * TARIFA_HORA;
        }  

        //En este caso estamos usando override tambien para sobreescribir el metodo
        //de la clase vehiculo y al retornar estamos llamando a la clase padre para
        //que nos pase los datos de placa, marca, modelo, hora de entrada y lo estamos
        //concatenando con la capacidad de carga para que nos muestre toda esta información
        @Override
        public String mostrarInformacion(){
            return super.mostrarInformacion() + " Capacidad de carga: " + capacidadCarga + " toneladas";
        }
}