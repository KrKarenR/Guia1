
package com.mycompany.parqueadero;

//Clase motocicleta que hereda de vehiculo
public class Motocicleta extends Vehiculo {

        //En este caso se define la constante TARIFA_HORA para que pueda ser compartida
        //con todos los objetos de motocicleta y como final para que no se pueda modificar
        //despues de asignarla, allí se define el valor de hora para las motocicletas.
        private static final double TARIFA_HORA = 8040;
        private int cilindraje;

        //Clase de tipo constructor en este caso se usa super para acceeder a la
        //clase padre que en este caso es Vehiculo, ya que motocicleta extiende de vehiculo.
        public Motocicleta(String placa, String marca, String modelo, int cilindraje){
            super(placa, marca, modelo);
            this.cilindraje = cilindraje;
        }

        //Getter y Setter del atributo cilindraje
        public int getCilindraje() {
            return cilindraje;
        }

        public void setCilindraje(int cilindraje) {
            this.cilindraje = cilindraje;
        }

        //Este metodo ya está definido en la clase padre, en este caso lo que
        //hacemos con override es sobreescribir ya que en este caso dentro de la
        //clase motocicleta ya definimos la tarifa hora por lo que es necesario
        //sobreescribir el contenido de este metodo para implementarlo.
        @Override
        public double calcularTarifa(long horas){
            return horas * TARIFA_HORA;
        }

        //En este caso estamos usando override tambien para sobreescribir el metodo
        //de la clase vehiculo y al retornar estamos llamando a la clase padre para
        //que nos pase los datos de placa, marca, modelo, hora de entrada y lo estamos
        //concatenando con el cilindraje para que nos muestre toda esta información
        @Override
        public String mostrarInformacion(){
            return super.mostrarInformacion() + " Cilindraje: " + cilindraje + "cc";
        }

}